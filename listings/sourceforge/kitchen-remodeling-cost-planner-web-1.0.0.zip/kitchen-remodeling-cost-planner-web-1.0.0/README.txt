Kitchen Remodeling Cost Planner - offline web calculator

Open index.html in any browser. No install, no network calls.
Split a kitchen remodel budget into 12 line items with sales tax, a contingency reserve and a permit allowance, or start from a Cost vs Value preset.

Homepage: https://wakitchenremodelingbellevue.com/
Source: https://github.com/nbkdevs/kitchen-remodeling-bellevue
License: MIT
